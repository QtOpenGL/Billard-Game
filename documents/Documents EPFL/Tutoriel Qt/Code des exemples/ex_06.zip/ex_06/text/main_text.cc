#include <iostream>
#include "text_viewer.h"
#include "contenu.h"
using namespace std;

int main()
{
  TextViewer ecran(cout);
  Contenu c(&ecran);
  c.dessine();
  return 0;
}
