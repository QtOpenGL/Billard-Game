#include <QGLContext>
#include "vue_opengl.h"
#include "vertex_shader.h" // Identifiants Qt de nos différents attributs
#include "contenu.h"

// ======================================================================
VueOpenGL::~VueOpenGL()
{
  // Libère la mémoire des textures

  QGLContext* context =  const_cast<QGLContext*>(QGLContext::currentContext());
  
  context->deleteTexture(textureDeChat);
  context->deleteTexture(textureFractale);
}

// ======================================================================
void VueOpenGL::dessine(Contenu const& a_dessiner)
{
  Q_UNUSED(a_dessiner); // dans cet exemple simple on n'utilise pas le paramètre

   // Dessine le 1er cube (à l'origine)
  dessineCube();

  QMatrix4x4 matrice;
  // Dessine le 2e cube
  matrice.translate(0.0, 1.5, 0.0);
  matrice.scale(0.25);
  dessineCube(matrice);

  // Dessine le 3e cube
  matrice.setToIdentity();
  matrice.translate(0.0, 0.0, 1.5);
  matrice.scale(0.25);
  matrice.rotate(45.0, 0.0, 1.0, 0.0);
  dessineCube(matrice);
}

// ======================================================================
void VueOpenGL::init()
{
  // Initialisation des shaders
  
  prog.addShaderFromSourceFile(QGLShader::Vertex,   ":/vertex_shader.glsl");
  prog.addShaderFromSourceFile(QGLShader::Fragment, ":/fragment_shader.glsl");

  prog.bindAttributeLocation("sommet",  SommetId);
  prog.bindAttributeLocation("coordonnee_texture", CoordonneeTextureId);

  prog.link();
  prog.bind();

  glEnable(GL_DEPTH_TEST);
  glEnable(GL_CULL_FACE);

  // Préparation d'une première texture à partir d'une image (cat.jpeg).
  QGLContext* context =  const_cast<QGLContext*>(QGLContext::currentContext());
  textureDeChat = context->bindTexture(QPixmap(":/cat.jpeg"), GL_TEXTURE_2D);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_MIRRORED_REPEAT);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_MIRRORED_REPEAT);
  // Autres variantes au lieu de GL_MIRRORED_REPEAT : GL_REPEAT, GL_CLAMP_TO_EDGE

  // Préparation d'une seconde texture.
  // S'il y devait y en avoir plus, on ferait bien sûr une fonction ;-)
  textureFractale = context->bindTexture(QPixmap(":/mandelbrot.jpeg"), GL_TEXTURE_2D);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_MIRRORED_REPEAT);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_MIRRORED_REPEAT);

  // initialisation de la caméra
  initializePosition();
}

// ======================================================================
void VueOpenGL::initializePosition()
{
  // position initiale
  matrice_vue.setToIdentity();
  matrice_vue.translate(0.0, 0.0, -4.0);
  matrice_vue.rotate(60.0, 0.0, 1.0, 0.0);
  matrice_vue.rotate(45.0, 0.0, 0.0, 1.0);
}

// ======================================================================
void VueOpenGL::translate(double x, double y, double z)
{
  /* Multiplie la matrice de vue par LA GAUCHE.
   * Cela fait en sorte que la dernière modification apportée
   * à la matrice soit appliquée en dernier (composition de fonctions).
   */
  QMatrix4x4 translation_supplementaire;
  translation_supplementaire.translate(x, y, z);
  matrice_vue = translation_supplementaire * matrice_vue;
}

// ======================================================================
void VueOpenGL::rotate(double angle, double dir_x, double dir_y, double dir_z)
{
  // Multiplie la matrice de vue par LA GAUCHE
  QMatrix4x4 rotation_supplementaire;
  rotation_supplementaire.rotate(angle, dir_x, dir_y, dir_z);
  matrice_vue = rotation_supplementaire * matrice_vue;
}

// ======================================================================
void VueOpenGL::dessineCube (QMatrix4x4 const& point_de_vue)
{
  prog.setUniformValue("vue_modele", matrice_vue * point_de_vue);

  /// Indique au shader quelle numéro de texture il doit utiliser (0,1,2,...)
  prog.setUniformValue("textureId", 0);

  /// Attribut la texture 'textureDeChat' à la texture numéro 0 du shader
  glActiveTexture(GL_TEXTURE0);
  glBindTexture(GL_TEXTURE_2D, textureDeChat);

  // Commence le dessin du cube.
  // On dessine le cube en deux étapes pour pouvoir changer de texture.
  glBegin(GL_QUADS);
  // X+
  prog.setAttributeValue(CoordonneeTextureId, 0.0, 0.0);
  prog.setAttributeValue(SommetId, +1.0, -1.0, -1.0);
  prog.setAttributeValue(CoordonneeTextureId, 1.0, 0.0);
  prog.setAttributeValue(SommetId, +1.0, +1.0, -1.0);
  prog.setAttributeValue(CoordonneeTextureId, 1.0, 1.0);
  prog.setAttributeValue(SommetId, +1.0, +1.0, +1.0);
  prog.setAttributeValue(CoordonneeTextureId, 0.0, 1.0);
  prog.setAttributeValue(SommetId, +1.0, -1.0, +1.0);

  // X-
  prog.setAttributeValue(CoordonneeTextureId, 0.0, 0.0);
  prog.setAttributeValue(SommetId, -1.0, -1.0, -1.0);
  prog.setAttributeValue(CoordonneeTextureId, 1.0, 0.0);
  prog.setAttributeValue(SommetId, -1.0, -1.0, +1.0);
  prog.setAttributeValue(CoordonneeTextureId, 1.0, 1.0);
  prog.setAttributeValue(SommetId, -1.0, +1.0, +1.0);
  prog.setAttributeValue(CoordonneeTextureId, 0.0, 1.0);
  prog.setAttributeValue(SommetId, -1.0, +1.0, -1.0);

  // Y+
  prog.setAttributeValue(CoordonneeTextureId, 0.0, 0.0);
  prog.setAttributeValue(SommetId, -1.0, +1.0, -1.0);
  prog.setAttributeValue(CoordonneeTextureId, 1.0, 0.0);
  prog.setAttributeValue(SommetId, -1.0, +1.0, +1.0);
  prog.setAttributeValue(CoordonneeTextureId, 1.0, 1.0);
  prog.setAttributeValue(SommetId, +1.0, +1.0, +1.0);
  prog.setAttributeValue(CoordonneeTextureId, 0.0, 1.0);
  prog.setAttributeValue(SommetId, +1.0, +1.0, -1.0);
  glEnd();

  /// On remplace la précédente texture de chat par la texture de fractale
  glActiveTexture(GL_TEXTURE0); // On la lie à nouveau au numéro 0 (comme ca on a pas besoin de changer "textureId" du shader)
  glBindTexture(GL_TEXTURE_2D, textureFractale);

  // Continue le dessin du cube.
  glBegin(GL_QUADS);
  // Y-
  prog.setAttributeValue(CoordonneeTextureId, 0.0, 0.0);
  prog.setAttributeValue(SommetId, -1.0, -1.0, -1.0);
  prog.setAttributeValue(CoordonneeTextureId, 1.0, 0.0);
  prog.setAttributeValue(SommetId, +1.0, -1.0, -1.0);
  prog.setAttributeValue(CoordonneeTextureId, 1.0, 1.0);
  prog.setAttributeValue(SommetId, +1.0, -1.0, +1.0);
  prog.setAttributeValue(CoordonneeTextureId, 0.0, 1.0);
  prog.setAttributeValue(SommetId, -1.0, -1.0, +1.0);

  // Z+
  prog.setAttributeValue(CoordonneeTextureId, 0.0, 0.0);
  prog.setAttributeValue(SommetId, -1.0, -1.0, +1.0);
  prog.setAttributeValue(CoordonneeTextureId, 1.0, 0.0);
  prog.setAttributeValue(SommetId, +1.0, -1.0, +1.0);
  prog.setAttributeValue(CoordonneeTextureId, 1.0, 1.0);
  prog.setAttributeValue(SommetId, +1.0, +1.0, +1.0);
  prog.setAttributeValue(CoordonneeTextureId, 0.0, 1.0);
  prog.setAttributeValue(SommetId, -1.0, +1.0, +1.0);

  // Z-
  prog.setAttributeValue(CoordonneeTextureId, 0.0, 0.0);
  prog.setAttributeValue(SommetId, -1.0, -1.0, -1.0);
  prog.setAttributeValue(CoordonneeTextureId, 1.0, 0.0);
  prog.setAttributeValue(SommetId, -1.0, +1.0, -1.0);
  prog.setAttributeValue(CoordonneeTextureId, 1.0, 1.0);
  prog.setAttributeValue(SommetId, +1.0, +1.0, -1.0);
  prog.setAttributeValue(CoordonneeTextureId, 0.0, 1.0);
  prog.setAttributeValue(SommetId, +1.0, -1.0, -1.0);

  glEnd();
}
